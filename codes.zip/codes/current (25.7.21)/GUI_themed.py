# -*- coding: utf-8 -*-
"""
Created on Tue Aug 17 18:49:15 2021

@author: Shahira Yasmin
"""
#from tkinter import *
import tkinter as tk
from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image

import os
import glob   #for finding pathnames
#import os.path

import matplotlib   #for plotting graph
matplotlib.use("TkAgg")

#importing canvas and the tools for forward,back,zoom,save
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg #, NavigationToolbar2TkAgg
try:
    from matplotlib.backends.backend_tkagg import NavigationToolbar2TkAgg
except ImportError:
    from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk as NavigationToolbar2TkAgg
from matplotlib.animation import FuncAnimation #for live updates
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.widgets import CheckButtons

from itertools import count
import pandas as pd
import numpy as np #for average

import datetime
import serial
import csv
import keyboard 
#%%


gui = tk.Tk()  #creating a blank window
gui.title("MSc Project")
#gui.attributes('-transparent', True)
gui.state('zoomed')
#%%
"""Setting theme and style configurations"""

#Credit and source for Sun Valley theme https://github.com/rdbende/Sun-Valley-ttk-theme
themepath=r"C:\Users\Shahira Yasmin\MSc Notes\Extended Research Project\Actual Project\codes\current (25.7.21)\Sun-Valley-ttk-theme"
themename="\sun-valley.tcl"
themeloc=themepath+themename

# Set the initial theme
gui.tk.call(r"source", themeloc)
gui.tk.call("set_theme", "light")

w, h = gui.winfo_screenwidth(), gui.winfo_screenheight()
gui.geometry("%dx%d+0+0" % (0.99 * w, 0.99 * h))

#configuring custom frames
style = ttk.Style(gui) #use this to configure styles of widgets
style.configure('HalfWindow.TFrame', width=w*0.49, height=0.99*h)
style.configure('Graph.TFrame', width=w*0.49, height="9.2i")
style.configure('TableOuter.TFrame', background="sky blue")
style.configure('TableInner.TFrame', width=300, height=150, background="LightSteelBlue2")

#Configuring custom buttons
style.configure('File.TButton', foreground="Green")
style.configure('Quit.TButton', foreground="Red")

#Configuring custom labels
style.configure('Table.TLabel', background="LightSteelBlue2", anchor="center", width=6, height=2)
style.configure('Caption.TLabel', background="LightSteelBlue2", anchor="center",  pady=1)

#%%
"""Functions for buttons"""

def change_theme():  #for button to change theme, from rdbende on Github
    # NOTE: The theme's real name is sun-valley-<mode>
    if gui.tk.call("ttk::style", "theme", "use") == "sun-valley-dark":
        # Set light theme
        gui.tk.call("set_theme", "light")
        
        graphfig.patch.set_facecolor('#fafafa')
        
        hand = Image.open("doublehand.jpg") #make sure image same folder as script
        hand = hand.resize((500, 500), Image.ANTIALIAS)
        hand = ImageTk.PhotoImage(hand)
        #picture1.configure(image=hand)
        #picture1.image = hand
        
        hand_canvas.itemconfig(image_id, image=hand)  
        
        

    else:
        # Set dark theme
        gui.tk.call("set_theme", "dark")
        
        #keeping custom configurations
        style.configure('HalfWindow.TFrame', width=w*0.49, height=0.99*h)
        style.configure('Graph.TFrame', width=w*0.49, height="9.2i")
        style.configure('TableOuter.TFrame', background="sky blue")
        style.configure('TableInner.TFrame', width=300, height=150, border="LightSteelBlue2")
        
        #font=("-weight", "bold")
        style.configure('File.TButton', foreground="spring green" )
        style.configure('Quit.TButton', foreground="Red")
        
        style.configure('Table.TLabel', anchor="center", width=6, height=2)
        style.configure('Caption.TLabel', anchor="center",  pady=1)
        graphfig.patch.set_facecolor('#000000')
        
        hand2 = Image.open("doublehand_dark.jpg") #make sure image same folder as script
        hand2 = hand2.resize((500, 500))
        hand2 = ImageTk.PhotoImage(hand2)
        #picture1.configure(image=hand2)
        #picture1.image = hand2

        hand_canvas.itemconfig(image_id, image=hand2)  
        

#Folder with script for reading sensor data, and csv of it
def update_file():
    global csvfile
    folder_path = r'C:\Users\Shahira Yasmin\MSc Notes\Extended Research Project\Actual Project\codes\current (25.7.21)'  #folder with reading arduino serial in
    file_type = '\*csv'
    files = glob.glob(folder_path + file_type)
    newest_file = max(files, key=os.path.getctime)
    csvfile = newest_file

def get_readings():
    data = pd.read_csv(csvfile)
    return data


def create_circle(x, y, r, canvasName): #center coordinates, radius
    x0 = x - r
    y0 = y - r
    x1 = x + r
    y1 = y + r
    return canvasName.create_oval(x0, y0, x1, y1)


# def run():  #for starting script that reads sensor data
#     try:      
#         os.system('Reading_1115_serial.py')
#         update_file()
#     except: pass
#%%

#%%
"""Organising layout of gui"""
#creating main division frames
leftFrame=ttk.Frame(gui, style='HalfWindow.TFrame')  
rightFrame=ttk.Frame(gui,style='HalfWindow.TFrame') 

#adding subframes to divide right side frame for graph, table, buttons
lsub_img=ttk.Frame(leftFrame, style='TFrame')

rsub_graph=ttk.Frame(rightFrame) #, style='Graph.TFrame')
rsub_table=ttk.Frame(rightFrame, style='TableOuter.TFrame')
rsub_buttons=ttk.Frame(rightFrame)

#packing in frames and subframes
leftFrame.pack(side="left", padx=10, pady=10)
lsub_img.pack()

rightFrame.pack(side="right", padx=10)
rsub_buttons.pack(side="bottom", padx=10, pady=20) #placement assignment is sequential
rsub_table.pack(side="bottom", padx=10, pady=10)
rsub_graph.pack(side="bottom")

"""Adding items to frames"""
value = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M")
timelabel = ttk.Label(rsub_buttons, text=value)
timelabel.pack(side="left", padx=10)

filebutton = ttk.Button(rsub_buttons, text="Update CSV File", style='File.TButton', command=update_file) 
filebutton.pack(side="left", padx=10)  #displays a button that starts the reading serial data script

quitbutton = ttk.Button(rsub_buttons, text="Exit", style='Quit.TButton', command=gui.destroy)
quitbutton.pack(side="left", padx=10)

changebutton = ttk.Button(rsub_buttons, text="Change theme", command=change_theme)
changebutton.pack(side="left", padx=10)

#%%
"""Creating Live Graph"""
update_file()

#optional, for defining graph figure size
graphfig = Figure(figsize=(8.5,6))
sub=graphfig.add_subplot(111)  #crucial for embedding plot in gui

plt.style.use('fivethirtyeight')
graphfig.patch.set_facecolor('#fafafa')

index = count()
samples = 300
def animate(i):
    data=get_readings()
    slice = slice_csv(data)
    
    update_table(slice)
    update_circles(slice)
    
    x = data.index#['millis']
    sensor0 = data['halls1']
    sensor1 = data['halls2']
    sensor2 = data['halls3']
    sensor3 = data['halls4']
    sensor4 = data['halls5']
    sensor5 = data['halls6']
    sensor6 = data['halls7']
    sensor7 = data['halls8']
    y_mean = [np.mean(sensor0[-70:])]*len(x[-70:])
    
    sub.cla()  #clears the current axes, reduces mess
    #add.cla()
    
    #edit to add.plot if using that method
    h0=sub.plot(x[-samples:], sensor0[-samples:], label='halls1', color="#a49", linewidth=1)
    h1=sub.plot(x[-samples:], sensor1[-samples:], label='halls2', color="#825", linewidth=1)
    h2=sub.plot(x[-samples:], sensor2[-samples:], label='halls3', color="#c67", linewidth=1)
    h3=sub.plot(x[-samples:], sensor3[-samples:], label='halls4', color="#dc7", linewidth=1)
    h4=sub.plot(x[-samples:], sensor4[-samples:], label='halls5', color="#993", linewidth=1)
    h5=sub.plot(x[-samples:], sensor5[-samples:], label='halls6', color="#173", linewidth=1)
    h6=sub.plot(x[-samples:], sensor6[-samples:], label='halls7', color="#4a9", linewidth=1)
    h7=sub.plot(x[-samples:], sensor7[-samples:], label='halls8', color="#8ce", linewidth=1)
    #sub.plot(x[-70:], y_mean[-70:], label='Mean', color="black", linestyle='--')
      # [-samples:] how far back to draw graph, change all 6 together, or remove [] completely 
      #comment out and change labels to change display
    
    sub.set_ylabel("Force (N)")
    
    #y.set_rotation(0)
    
    sub.legend()
    #lines = [h0,h1,h2,h3,h4,h5,h6,h7]
    #labels = [str(line.get_label()) for line in lines]
    #visibility = [line.get_visible() for line in lines]
    #check = CheckButtons(rax, labels, visibility)
    #graphfig.legend((h0,h1,h2,h3,h4,h5,h6,h7),(labels))
    #sub.tight_layout()
    
    #def func(label):
        # index = labels.index(label)
        # lines[index].set_visible(not lines[index].get_visible())
        # plt.draw()
    
    #check.on_clicked(func)

    sub.annotate("Mean: "+ str(round(y_mean[0],2  )),
            xy=(1, 0), xycoords='axes fraction',
            xytext=(-20, 20), textcoords='offset pixels',
            bbox=dict(boxstyle="round", fc="0.8"),
            horizontalalignment='right',
            verticalalignment='bottom')
    
    #plt.tight_layout()

#adding graph to top of right frame
canvas = FigureCanvasTkAgg(graphfig, master=rsub_graph) 
canvas.draw()
canvas.get_tk_widget().pack(side="bottom")
#canvas._tkcanvas.pack(side='top', padx=10, pady=10)

#canvas.configure(bg='cyan')
#adding a toolbar for navigating the livegraph
toolbar= NavigationToolbar2TkAgg(canvas,rightFrame) #place toolbar at top of rightframe
toolbar.update()
canvas._tkcanvas.pack(side="top", padx=5)

#%%
"""Creating table of live sensor readings"""

#defining frame to contain the table
table = ttk.Frame(rsub_table, style = 'TableInner.TFrame')
table.pack(padx=5, pady=5) #placing table in rsub_table frame

#including table caption and column headers
tablename=ttk.Label(table, text='Sensor Analogue Readings', style='Caption.TLabel', font=("-size", 15))
tablename.grid(row=0, columnspan=8, sticky=NSEW)

for n in range(1,9):    
    headers=ttk.Label(table, text=n, style= 'Table.TLabel', font=("-size",13) )
    headers.grid(row=1,column=n-1, sticky=NSEW)


def slice_csv(data):
    slice=data.iloc[-3:,1:] #slicing last 3 rows of csv data, dropping the milliseconds column
    slice.columns = range(1,len(slice.columns)+1) #renaming csv columns to integers 1-8
    slice.reset_index(drop=True, inplace=True)    #renaming csv row index to integers 0-2
    return slice

data=get_readings()
slice=slice_csv(data)


#populating table data
cells={}
cellnum=0
r = 2
c = 0
for col in slice.columns:
    for reading in slice.loc[:,col]:
        name=f"cell{cellnum}"     #using dynamic labels to change cells, live
        cells[name] = ttk.Label(table, text=round(reading,3), style='Table.TLabel')
        cells[name].grid(row=r, column=c)
        cellnum += 1
        r += 1
    r=2  #reset row numbering
    c += 1  #advance to next column

def update_table(slice):
    r = 2
    c = 0
    cellnum=0
    for col in slice.columns:
        for reading in slice.loc[:,col]:
            name=f"cell{cellnum}"     #using dynamic labels to change cells, live
            cells[name].configure(text=round(reading,3))
            cellnum += 1
            r += 1
        r=2  #reset row numbering
        c += 1  #advance to next column
    
    

#%%
"""Adding hand image"""
    
hand = Image.open("doublehand.jpg") #make sure image same folder as script
hand = hand.resize((520, 520), Image.ANTIALIAS)
hand = ImageTk.PhotoImage(hand)
# picture1 = ttk.Label(lsub_img, image = hand)
# picture1.image = hand
# picture1.pack(side="right", padx=50)

#%%

### Alternative hand image test
# create the canvas, size in pixels
hand_canvas = Canvas(width=520, height=520)
# pack the canvas into a frame/form
hand_canvas.pack(side="right", padx=50)
# pic's upper left corner (NW) on the canvas is at x=50 y=10
image_id=hand_canvas.create_image(260, 250, image=hand)

size=11

c1 = create_circle(250, 193, size, hand_canvas) #returns ID
c2 = create_circle(441, 252, size, hand_canvas) #x,y co-ordinates, radius, canvas
c3 = create_circle(445, 285, size, hand_canvas)
c4 = create_circle(450, 180, size, hand_canvas)
c5 = create_circle(194, 56,  size, hand_canvas)
c6 = create_circle(169, 57,  size, hand_canvas)
c7 = create_circle(405, 87,  size, hand_canvas)
c8 = create_circle(128, 53,  size, hand_canvas)
circles = (c1,c2,c3,c4,c5,c6,c7,c8)

def update_circles(slice):
    circle_num = 0
    fillcolor ='#00f' #blue if theres an error
    color_list = ['#FF0000','#FF3E20','#FF603B','#FF8054','#FF9E6E','#FFBD89','#FFDBA4','#FFFABF','#FFFFDC','#FFFFF9']
    for reading in slice.iloc[-1,:]:
        if reading > 4:
            fillcolor = color_list[0]
        elif reading > 3.5:
            fillcolor = color_list[1]
        elif reading > 3:
            fillcolor = color_list[2]
        elif reading > 2.5:
            fillcolor = color_list[3]
        elif reading > 2:
            fillcolor = color_list[4]
        elif reading > 1.5:
            fillcolor = color_list[5]
        elif reading > 1:
            fillcolor = color_list[6]
        elif reading > 0.5:
            fillcolor = color_list[7]
        elif reading > 0.25:
            fillcolor = color_list[8]
        elif reading > 0.01:
            fillcolor = color_list[9]
            
        else:
            fillcolor = ''
        hand_canvas.itemconfig(circles[circle_num], fill=fillcolor)  
        circle_num += 1
        



ani = FuncAnimation(graphfig, animate, interval=50)  #interval is how often graph updates in ms, limited by pc speed and serial rate
gui.mainloop()  #keeps window on screen or running till closed.
