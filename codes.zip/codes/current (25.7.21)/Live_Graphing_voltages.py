import glob   #for finding pathnames
import os.path

folder_path = r'C:\Users\Shahira Yasmin\MSc Notes\Extended Research Project\Actual Project\codes\current (25.7.21)'  #folder with reading arduino serial in
file_type = '\*csv'
files = glob.glob(folder_path + file_type)
newest_file = max(files, key=os.path.getctime)

from itertools import count
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import numpy as np #for average

plt.style.use('fivethirtyeight')

index = count()

samples = 300

def animate(i):
    data = pd.read_csv(newest_file)
    
    x = data['millis']
    sensor0 = data['halls1']
    sensor1 = data['halls2']
    sensor2 = data['halls3']
    sensor3 = data['halls4']
    sensor4 = data['halls5']
    sensor5 = data['halls6']
    sensor6 = data['halls7']
    sensor7 = data['halls8']
    y_mean = [np.mean(sensor7[-samples:])]*len(x[-samples:])
    
    plt.cla()

    plt.plot(x[-samples:], sensor0[-samples:], label='halls1', color="#a49")
    plt.plot(x[-samples:], sensor1[-samples:], label='halls2', color="#825")
    plt.plot(x[-samples:], sensor2[-samples:], label='halls3', color="#c67")
    plt.plot(x[-samples:], sensor3[-samples:], label='halls4', color="#dc7")
    plt.plot(x[-samples:], sensor4[-samples:], label='halls5', color="#993")
    plt.plot(x[-samples:], sensor5[-samples:], label='halls6', color="#173")
    plt.plot(x[-samples:], sensor6[-samples:], label='halls7', color="#4a9")
    plt.plot(x[-samples:], sensor7[-samples:], label='halls8', color="#8ce")
    plt.plot(x[-samples:], y_mean[-samples:], label='Mean', color="black", linestyle='--')
      # [-samples:] how far back to draw graph, change all 6 together, or remove [] completely 
      #comment out and change labels to change display
    
    plt.legend(loc='best')
    plt.tight_layout()

    plt.annotate("Mean: "+ str(round(y_mean[0],2  )),
            xy=(1, 0), xycoords='axes fraction',
            xytext=(-20, 20), textcoords='offset pixels',
            bbox=dict(boxstyle="round", fc="0.8"),
            horizontalalignment='right',
            verticalalignment='bottom')
    


ani = FuncAnimation(plt.gcf(), animate, interval=5)  #interval is how often this updates, limited by pc speed and serial rate

plt.tight_layout()
plt.show()