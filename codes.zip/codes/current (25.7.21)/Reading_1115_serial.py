import serial

import csv

import datetime

import keyboard 

def bits_to_grams(analogue):
    return max(0,(0.108565*float(analogue) - 1742.5)) #set -ve values to 0 


def bits_to_force(analogue):
    return max(0,((0.108565*float(analogue) - 1742.5) * 0.00980665)) #set -ve values to 0 

serialcomm = serial.Serial('COM3', 115200) #com port 

serialcomm.timeout = 1

frame = 0
oldframe = 0

filename = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M.csv")
fieldnames = ["millis", "halls1","halls2","halls3","halls4","halls5","halls6","halls7","halls8"] 


with open(filename, 'a',newline='') as csvfile:
    csv_writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    csv_writer.writeheader()
 
while True:

    frame = serialcomm.readline().decode('ascii').strip().split(",")
    
    if oldframe != frame and len(frame)==9:
        
        with open(filename, 'a',newline='') as csv_file: ##newline work around, so it doen't double up
            csv_writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            
            info = {
                "millis": bits_to_force(frame[0]),
                "halls1": bits_to_force(frame[1]),
                "halls2": bits_to_force(frame[2]),
                "halls3": bits_to_force(frame[3]),
                "halls4": bits_to_force(frame[4]),
                "halls5": bits_to_force(frame[5]),
                "halls6": bits_to_force(frame[6]),
                "halls7": bits_to_force(frame[7]),
                "halls8": bits_to_force(frame[8]),
                }
      
            csv_writer.writerow(info)
            print(info)
 
        oldframe=frame

        try:  # used try so that if user pressed other than the given key error will not be shown
            if keyboard.is_pressed('q'):  # if key 'q' is pressed 
                print('You pressed q, quitting ')
                break  # finishing the loop
        except:
                pass
serialcomm.close()

