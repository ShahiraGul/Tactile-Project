Codes for reading and recording data from tactile sensors in this project. 
Data can be visualised with either the Livegrapher python script in a continuously updating graph, or with the GUI_themed python script.

Author: Shahira Gul   syg100103@gmail.com   Sept 2021
-----------------------------------------------------------

1. Flash Arduino with INO file. Two options:

Option A:  read continuously (1115_Serial)

Option B:  record data in fixed intervals of ~5 seconds (can be edited in the INO code) upon the press of the button.
Use the 1115_Serial_triggered INO file, with the button added to the protoshield.The LED light turns on during that interval.

** When using this mode of data collection, do step 4 AFTER the first button
press not before.**


2. Rename folder path in Livegrapher and GUI_themed python scripts


3. Launch Spyder. Change COM port to one that arduino is attached to (can find out on the Arduino IDE). Run "Reading_1115_Serial.py"


4. Using VSCode, or manual commands, or in a new spyder console, 
run "Live_Graphing_voltages" OR "GUI_themed.py"
 (eg using anaconda prompt, cd to folder with script, type in "Live_Graphing_voltages.py")
--------------------------------------------------------------
